Instructions for the demo

Note: this folder must be in the examples folder

Left mouse click to add a small ball inside the cube.
Right mouse click to add a large ball inside the cube.
Press up key to apply an upward force to the balls.
Press down key to apply a downward force to the balls.
Press left key to apply a force to the left to the balls.
Press right key to apply a force to the right to the balls.
Press U to rotate on x axis by -1 degree
Press J to rotate on x axis by 1 degree
Press I to rotate on y axis by -1 degree
Press K to rotate on y axis by 1 degree
Press O to rotate on z axis by -1 degree
Press L to rotate on z axis by 1 degree